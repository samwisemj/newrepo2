import java.io.IOException;

import com.cg.ui.UIEmployee;

public class MainClass {

	public static void main(String[] args) throws NumberFormatException, IOException {
		new UIEmployee().start();

	}

}
