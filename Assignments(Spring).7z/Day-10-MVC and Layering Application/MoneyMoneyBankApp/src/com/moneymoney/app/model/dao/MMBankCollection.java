package com.moneymoney.app.model.dao;

import com.moneymoney.framework.account.dao.BankAccountCollection;

public class MMBankCollection extends BankAccountCollection {
//super is implied implicitly
	
	
}
