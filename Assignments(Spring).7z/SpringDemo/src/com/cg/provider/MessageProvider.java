package com.cg.provider;

public interface MessageProvider {
	String getMessage();

}
