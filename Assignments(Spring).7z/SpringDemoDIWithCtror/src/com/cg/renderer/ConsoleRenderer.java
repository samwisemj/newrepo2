package com.cg.renderer;

import com.cg.provider.MessageProvider;

public class ConsoleRenderer implements  MessageRenderer {

	MessageProvider provider;
	
	
	
		
	public ConsoleRenderer() {
	}

	public ConsoleRenderer(MessageProvider provider) {
		this.provider = provider;
	}


	@Override
	public void render() {
		System.out.println(provider.getMessage());
		
	}	
}
