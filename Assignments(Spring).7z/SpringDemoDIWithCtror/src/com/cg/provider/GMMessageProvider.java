package com.cg.provider;

public class GMMessageProvider implements MessageProvider {

	
	public GMMessageProvider() {
		System.out.println("Ctor of provider.....GM");
		
	}

	@Override
	public String getMessage() {
	
		return "Good Morning";
	}

}
