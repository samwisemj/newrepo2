package com.cg.provider;

public class HWMessageProvider implements MessageProvider {

	
	public HWMessageProvider() {
	System.out.println("Ctor from HW provider");
	}

	@Override
	public String getMessage() {
		// TODO Auto-generated method stub
		return "Hello World";
	}

}
