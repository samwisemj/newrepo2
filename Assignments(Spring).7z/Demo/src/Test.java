import com.cg.factory.MessageFactory;

public class Test {

	public static void main(String[] args) throws InstantiationException, IllegalAccessException, ClassNotFoundException {
	
		MessageFactory.getMessageRenderer().render();
}

}
